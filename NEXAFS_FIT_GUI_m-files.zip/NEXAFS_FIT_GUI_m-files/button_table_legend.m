function button_table_legend(src,evnt)
%   Callback for the push button of the "nexafs_table_legend" - figure.
%   Opens an overview of the mathematical models available for fitting
%   spectra.

math_models_nexafs;

end